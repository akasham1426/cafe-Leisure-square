# 

Coffee Shop Management System - A mini project using the basic concepts of Database Management System
